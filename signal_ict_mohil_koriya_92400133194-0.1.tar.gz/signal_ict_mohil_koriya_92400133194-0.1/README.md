```bash
pip install signal_ICT_Mohil_koriya_92400133194
